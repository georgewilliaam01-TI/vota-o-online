CREATE POLICY "candidatos_public_read" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'candidatos');
CREATE POLICY "candidatos_admin_insert" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'candidatos' AND public.is_admin());
CREATE POLICY "candidatos_admin_update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'candidatos' AND public.is_admin());
CREATE POLICY "candidatos_admin_delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'candidatos' AND public.is_admin());